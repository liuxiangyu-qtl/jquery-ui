var interval = 10; // ms
var idx = 0;
var fr=new FileReader();
var lines;
var images;
var idxArr;
var markPoints;

const markSize = 10;

function printData(x, y) {
    var point = transformPoint(x, y);

    ctx.lineTo(point.x, point.y);
	ctx.stroke();
}

function printMarks() {
    var p = transformPoint(markPoints[0].x, markPoints[0].y);
    drawCircle(ctx, p.x, p.y, markSize);

    p = transformPoint(markPoints[1].x, markPoints[1].y);
    drawTriangle(ctx, p.x, p.y, markSize);

    p = transformPoint(markPoints[2].x, markPoints[2].y);
    drawX(ctx, p.x, p.y, markSize);
}

function display() {
	var line = lines[idx];
	var arr = line.split(',');
	var key = arr[1];
	var x = arr[3];
	var y = arr[2];
	if (images[key]) {
        ctx.drawImage(images[key], -y_axis_distance_grid_lines*grid_size-imageWidth, -x_axis_distance_grid_lines*grid_size, imageWidth, imageHeight);
	} else {
		console.log('image match ' + key + ' not found.');
	}
    printData(x, y);
	idx++;
    if (idx < lines.length) {
        setTimeout(display, interval);
    } else {
        printMarks();
        setTimeout(function() {
            recorder.stop();
        }, 1000);
	}
}

function start() {
    markPoints = mark(lines);
//	clearAxis();
//	initAxis();
	idx = 0;
	ctx.beginPath();
	ctx.strokeStyle = "red";
	ctx.moveTo(0, 0);
    display();
    setTimeout(function() {
        recorder.start();
    }, interval);
}

function transformPoint(x, y) {
    x = x*grid_size/x_axis_starting_point.number+0.5;
    y = -y*grid_size/y_axis_starting_point.number+0.5;
    return { x, y };
}

//IHD-A50-3 Data 2020_01_09 11_10_30.595.jpg -> 11:10:31
function transformName(name) {
	var arr = name.split(' ');
	var time = arr[arr.length-1].replace('.jpg', '');
	arr = time.split('_');
	arr[2] = parseFloat(arr[2]).toFixed(0);
    if (arr[2] == '60') {
        arr[2] = '00';
        arr[1] = parseInt(arr[1])+1+'';
        arr[1] = arr[1].padStart(2, '0');
    } else {
        arr[2] = arr[2].padStart(2, '0');
    }
    if (arr[1] == '60') {
        arr[1] = '00';
        arr[0] = parseInt(arr[0])+1+'';
        arr[0] = arr[0].padStart(2, '0');
    }
	return arr.join(':');
}

function mark(lines) {
	var k;
	var max = 0;
    var result = [{}, {}, {}];
	var lastPoint = { 'x': 0, 'y': 0 };
	$.each(lines, function(idx, line) {
		var arr = line.split(',');
		var x = parseFloat(arr[3]);
		var y = parseFloat(arr[2]);

		k = (y - lastPoint.y)/(x - lastPoint.x);
		if (y > max) {
			max = y;
            result[1].x = x;
            result[1].y = y;
		}
        if (!result[0].y && k < 0 && y > 10) {
            result[0].x = x;
            result[0].y = y
		}
        if (!result[2].y && k < -10 && (x - lastPoint.x > 0.1)) {
            result[2].x = lastPoint.x;
            result[2].y = lastPoint.y;
		}
		lastPoint.x = x;
		lastPoint.y = y;
	});
	return result;
}

$(function() {
	$('#start').click(start);
	$('#inputfile').change(function() { 
		fr.onload=function(){ 
			lines = fr.result.split('\n');
		}
        images = {};
		$.each(this.files, function(idx, file) {
			if (file.name.endsWith('csv')) {
				fr.readAsText(file);
			} else {
				var key = transformName(file.name);
                images[key] = new Image();
                images[key].src = './files/' + file.name;
			}
		});
	});
	initAxis();
});

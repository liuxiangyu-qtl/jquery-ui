const markColor = '#000000';
const sqrt3 = Math.sqrt(3);
const markWidth = 2;

function drawCircle(ctx, x, y, size) {
	var style = ctx.strokeStyle;
    var lineWidth = ctx.lineWidth;
	var r = size/2;

	ctx.moveTo(x, y);
	ctx.beginPath();
    ctx.lineWidth = markWidth;
	ctx.strokeStyle = markColor;
	ctx.arc(x, y, r, 0, 2 * Math.PI);
	ctx.stroke();

	ctx.beginPath();
    ctx.lineWidth = lineWidth;
	ctx.strokeStyle = style;
}

function drawTriangle(ctx, x, y, size) {
	var style = ctx.strokeStyle;
    var lineWidth = ctx.lineWidth;
	var r = size * 2 / 3;

    ctx.beginPath();
	ctx.moveTo(x, y-r);
    ctx.lineWidth = markWidth;
	ctx.strokeStyle = markColor;
	ctx.lineTo(x+r*sqrt3/2, y+r/2);
	ctx.lineTo(x-r*sqrt3/2, y+r/2);
	ctx.lineTo(x, y-r);
	ctx.stroke();

	ctx.beginPath();
	ctx.moveTo(x, y);
    ctx.lineWidth = lineWidth;
	ctx.strokeStyle = style;
}

function drawX(ctx, x, y, size) {
	var style = ctx.strokeStyle;
    var lineWidth = ctx.lineWidth;
	var d = size/2;

    ctx.beginPath();
	ctx.moveTo(x-d, y-d);
    ctx.lineWidth = markWidth;
	ctx.strokeStyle = markColor;
	ctx.lineTo(x+d, y+d);
    ctx.stroke();
	ctx.moveTo(x-d, y+d);
	ctx.lineTo(x+d, y-d);
	ctx.stroke();

	ctx.beginPath();
	ctx.moveTo(x, y);
    ctx.lineWidth = lineWidth;
	ctx.strokeStyle = style;
}

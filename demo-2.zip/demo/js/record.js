var chunks = [];
const format='video/webm';
const frameRate = 60; // 录制帧率60fps

var recorder;

window.onload = function() {
    var canvas = document.querySelector('canvas');
    var ctx = canvas.getContext('2d');

    var stream = canvas.captureStream(frameRate);
    recorder = new MediaRecorder(stream, { type: format });

    recorder.onstart = function(e) {
        if (chunks.length) {
            chunks.pop();
        }
    }

    recorder.ondataavailable = function(e) {
        chunks.push(e.data);
    }

    recorder.onstop = function(e) {
        const blob = new Blob(chunks);
        const url = window.URL.createObjectURL(blob, { type: format });
        var video = document.querySelector('video');
        video.src = url;
    }
};

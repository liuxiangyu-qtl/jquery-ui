var interval = 10; // ms
var idx = 0;
var fr=new FileReader();
var lines;
var imageNames;

const imageCanvas = document.getElementById('image');
const imageCtx = imageCanvas.getContext('2d');

function displayImage(src) {
	var imageObj = new Image();
	imageObj.onload = function() {
		imageCtx.drawImage(imageObj, 0, 0, 288, 162);
	};
	imageObj.src = src;
}

function printData(x, y) {
	x = x*grid_size/x_axis_starting_point.number+0.5;
	y = y*grid_size/y_axis_starting_point.number+0.5;
    ctx.lineTo(x, y);
	ctx.stroke();
}

function display() {
	var line = lines[idx];
	var arr = line.split(',');
	var key = arr[1];
	var x = arr[3];
	var y = arr[2];
	if (imageNames[key]) {
		displayImage('files/' + imageNames[key]);
	} else {
		console.log('image match ' + key + ' not found.');
	}
    printData(x, y);
	idx++;
    if (idx < lines.length) {
        setTimeout(display, interval);
    }
}

function initAxis() {
    
}

function start() {
	idx = 0;
	ctx.beginPath();
	ctx.strokeStyle = "red";
	ctx.moveTo(0, 0);
    display();
}

//IHD-A50-3 Data 2020_01_09 11_10_30.595.jpg -> 11:10:31
function transformName(name) {
	var arr = name.split(' ');
	var time = arr[arr.length-1].replace('.jpg', '');
	arr = time.split('_');
	arr[2] = parseFloat(arr[2]).toFixed(0);
	return arr.join(':');
}

$(function() {
	$('#start').click(start);
	$('#inputfile').change(function() { 
		fr.onload=function(){ 
			lines = fr.result.split('\n');
		}
		imageNames = {};
		$.each(this.files, function(idx, file) {
			if (file.name.endsWith('csv')) {
				fr.readAsText(file);
			} else {
				var key = transformName(file.name);
				imageNames[key] = file.name;
			}
		});
	})
})
var interval = 10; // ms
var idx = 0;
var fr=new FileReader();
var lines;
var imageNames;
var idxArr;

const imageCanvas = document.getElementById('image');
const imageCtx = imageCanvas.getContext('2d');
const markSize = 5;

var canvasSize = imageCanvas.width;
var imageHeight = canvasSize * 108 / 192;
var imageWidth = canvasSize;

imageCtx.translate(canvasSize/2, canvasSize/2);
imageCtx.rotate(Math.PI / 2);
imageCtx.translate(-canvasSize/2, -canvasSize/2);

function displayImage(src) {
	var imageObj = new Image();
	//imageObj.crossOrigin = '';
	imageObj.onload = function() {
		imageCtx.drawImage(imageObj, 0, 0, imageWidth, imageHeight);
	};
	imageObj.src = src;
}

function printData(x, y) {
	x = x*grid_size/x_axis_starting_point.number+0.5;
	y = -y*grid_size/y_axis_starting_point.number+0.5;
    ctx.lineTo(x, y);
	ctx.stroke();

	if (idx == idxArr[0]) {
		drawCircle(ctx, x, y, markSize);
	} else if (idx == idxArr[1]) {
		drawTriangle(ctx, x, y, markSize);
	} else if (idx == idxArr[2]) {
		drawX(ctx, x, y, markSize);
	}
}

function display() {
	var line = lines[idx];
	var arr = line.split(',');
	var key = arr[1];
	var x = arr[3];
	var y = arr[2];
	if (imageNames[key]) {
		displayImage('files/' + imageNames[key]);
	} else {
		console.log('image match ' + key + ' not found.');
	}
    printData(x, y);
	idx++;
    if (idx < lines.length) {
        setTimeout(display, interval);
    } else {
		stopRecording();
	}
}

function start() {
	idxArr = cal(lines);
	clearAxis();
	initAxis();
	idx = 0;
	ctx.beginPath();
	ctx.strokeStyle = "red";
	ctx.moveTo(0, 0);
    display();
	startRecording();
}

//IHD-A50-3 Data 2020_01_09 11_10_30.595.jpg -> 11:10:31
function transformName(name) {
	var arr = name.split(' ');
	var time = arr[arr.length-1].replace('.jpg', '');
	arr = time.split('_');
	arr[2] = parseFloat(arr[2]).toFixed(0);
	arr[2] = arr[2].padStart(2, '0');
	return arr.join(':');
}

function cal(lines) {
	var k;
	var max = 0;
	var result = [0, 0, 0];
	var lastPoint = { 'x': 0, 'y': 0 };
	$.each(lines, function(idx, line) {
		var arr = line.split(',');
		var x = parseFloat(arr[3]);
		var y = parseFloat(arr[2]);

		k = (y - lastPoint.y)/(x - lastPoint.x);
		console.log(k, x, y);
		if (y > max) {
			max = y;
			result[1] = idx;
		}
		if (result[0] == 0 && k < 0 && y > 10) {
			result[0] = idx-1;
		}
		if (result[2] == 0 && k < -10 && (x - lastPoint.x > 0.1)) {
			result[2] = idx-1;
		}
		lastPoint.x = x;
		lastPoint.y = y;
	});
	return result;
}

$(function() {
	$('#start').click(start);
	$('#inputfile').change(function() { 
		fr.onload=function(){ 
			lines = fr.result.split('\n');
		}
		imageNames = {};
		$.each(this.files, function(idx, file) {
			if (file.name.endsWith('csv')) {
				fr.readAsText(file);
			} else {
				var key = transformName(file.name);
				imageNames[key] = file.name;
			}
		});
	});
	initAxis();
});

displayImage('1.jpg');
imageCtx.getImageData(0,0,100,100);
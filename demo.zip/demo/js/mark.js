const markColor = '#000000';
const sqrt3 = Math.sqrt(3);

function drawCircle(ctx, x, y, size) {
	var style = ctx.strokeStyle;
	var r = size/2;

	ctx.moveTo(x, y);
	ctx.beginPath();
	ctx.strokeStyle = markColor;
	ctx.arc(x, y, r, 0, 2 * Math.PI);
	ctx.stroke();

	ctx.beginPath();
	ctx.strokeStyle = style;
}

function drawTriangle(ctx, x, y, size) {
	var style = ctx.strokeStyle;
	var r = size * 2 / 3;

	ctx.moveTo(x, y-r);
	ctx.beginPath();
	ctx.strokeStyle = markColor;
	ctx.lineTo(x+r*sqrt3/2, y+r/2);
	ctx.lineTo(x-r*sqrt3/2, y+r/2);
	ctx.lineTo(x, y-r);
	ctx.stroke();

	ctx.beginPath();
	ctx.moveTo(x, y);
	ctx.strokeStyle = style;
}

function drawX(ctx, x, y, size) {
	var style = ctx.strokeStyle;
	var d = size/2;

	ctx.moveTo(x-d, y-d);
	ctx.beginPath();
	ctx.strokeStyle = markColor;
	ctx.lineTo(x+d, y+d);
	ctx.moveTo(x-d, y+d);
	ctx.lineTo(x+d, y-d);
	ctx.stroke();

	ctx.beginPath();
	ctx.moveTo(x, y);
	ctx.strokeStyle = style;
}
Steps:
1. excel 导出成 csv 格式文件，放到 files 目录下，删掉多余的行。可参考已有的 data.csv
2. 图片复制到 files 里
3. 打开 demo.html，选择文件时选中 csv 文件以及对应的图片
4. 点 start